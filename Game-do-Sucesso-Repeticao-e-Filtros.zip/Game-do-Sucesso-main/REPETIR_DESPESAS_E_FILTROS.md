# Repetir despesas e filtrar lançamentos

## Repetir despesas para este mês

Na aba Lançamentos, clique em **Repetir despesas**:

1. Escolha o mês de origem. A tela começa no mês anterior.
2. Confira o mês de destino. A tela começa no mês atual; o botão **Usar este mês** volta para ele.
3. Marque as despesas desejadas ou clique em **Selecionar disponíveis**.
4. Confira a quantidade, o total e as novas datas.
5. Clique em **Criar despesas pendentes**.

Também é possível usar o ícone de cópia ao lado de uma despesa específica.

As cópias mantêm descrição, categoria, valor e conta. O original não é alterado. Todas nascem pendentes e sem data de pagamento: repetir não desconta dinheiro do banco. Ao pagar, edite o lançamento, marque Pago e informe a data.

Cada despesa repetida por este recurso só é criada uma vez em cada mês. Repetir a cópia de fevereiro para março continua pertencendo à mesma sequência, sem criar duplicatas da mesma origem. Lançamentos parecidos cadastrados manualmente precisam de conferência, pois não têm vínculo de origem.

O dia de referência é preservado quando possível. Uma conta do dia 31 fica em 28/02 (29/02 em ano bissexto); ao repetir essa cópia para março, volta para 31/03. Se você quiser outro vencimento, edite a nova cópia.

Este recurso cria as cópias quando você confirma. Ele não cria agendamentos automáticos em segundo plano.

## Filtros

- **Escolher mês:** exibe somente um mês.
- **Mês anterior / Mês atual / Próximo mês:** navegação mensal.
- **Intervalo de datas:** informe De e Até; ambas as datas são incluídas. Datas vazias, inválidas ou invertidas não geram totais de outros períodos.
- **Todos os meses:** visão acumulada, identificada na tela.
- **Situação:** todas, pendentes ou pagos/recebidos.
- **Tipo e busca:** receitas, despesas e descrição/categoria.

Lista e totais usam os mesmos filtros. O período usa a data de referência, não o dia em que o registro foi cadastrado nem a data de pagamento. Novo Lançamento já começa no mês que estiver selecionado quando a tela estiver no modo mensal.

## Validação e publicação

Passaram 15 testes automatizados (14 na suíte principal e um teste adicional de interface), TypeScript e compilação. Foram verificados repetição sem desconto bancário, confirmação dupla, cópia já existente, fevereiro, ano bissexto, intervalo inclusivo e os filtros mensais anteriores.

Esta entrega atualiza os arquivos do projeto. O site público ainda precisa de publicação. Extraia este ZIP e substitua o conteúdo do projeto na raiz do GitHub; enviar somente o ZIP não aplica a mudança. Consulte PUBLICAR_CORRECAO_MENSAL.md para o procedimento.
