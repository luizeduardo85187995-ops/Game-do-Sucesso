# Aplicar a correção dos meses no site

## Diagnóstico confirmado em 16/11/2026

O site jornada-do-sucesso-swart.vercel.app/app estava servindo /assets/index-Uk0i98dI.js, sem os filtros de período presentes no projeto preparado aqui.

No repositório luizeduardo85187995-ops/Game-do-Sucesso, o commit bdecb7233d869fd7a07fd7a5ebf890a892279268 adicionou somente Game-do-Sucesso-corrigido.zip. Os arquivos dentro desse ZIP não substituíram src/ e os demais arquivos de código na raiz. A Vercel não aplica o conteúdo desse ZIP automaticamente.

O src/ do repositório já tinha uma versão inicial de filtro mensal, mas a versão pública não mostrava esse código. É necessário aplicar o conteúdo extraído e verificar a publicação de produção. Não foi possível consultar a configuração desse projeto na conta Vercel disponível; não foi confirmado se há build com falha, branch diferente ou implantação antiga.

## Como enviar os arquivos corretos

1. Baixe e extraia Game-do-Sucesso-Repeticao-e-Filtros.zip no Windows.
2. Abra a pasta Game-do-Sucesso-main que saiu da extração.
3. Envie o CONTEÚDO dessa pasta para a raiz do repositório: src/, api/, public/, tests/, package.json, package-lock.json, tsconfig.json, vite.config.ts, vercel.json e os demais arquivos do projeto. Preserve credenciais exclusivamente nas variáveis do servidor.
4. Não envie apenas o ZIP e não crie uma pasta Game-do-Sucesso-main dentro da raiz existente. package.json e src/ precisam estar diretamente na raiz usada para o build.
5. Confirme o commit e acompanhe a implantação Vercel vinculada ao repositório e à branch correta. O comando de build é npm run build, e a saída é dist.
6. Após o deploy de produção ficar Ready e ser associado ao domínio correto, recarregue o app com Ctrl+F5.

## Como reconhecer a versão corrigida

Acima dos totais, em Lançamentos, deve aparecer:
- Mês de referência e o nome do mês selecionado;
- campo Escolher mês;
- Mês anterior, Mês atual, Próximo mês e Todos os meses.

Ao abrir, o app mostra o mês atual. Outubro, novembro e dezembro não ficam juntos nessa visão. Lista, contador e cartões usam o mesmo conjunto de lançamentos. Busca e filtro de receitas/despesas também atualizam os totais. A visão Todos os meses é uma escolha explícita e exibe aviso de acumulado.

Esses totais são por data de referência e incluem pendentes. Não são o saldo bancário atual. A data do pagamento permanece separada. A correção não reescreve datas, saldos ou registros antigos.

## Testes

15 testes automatizados passaram, além de TypeScript e build. O teste da tela verifica mês anterior, atual e seguinte, acumulado, filtro por tipo e os respectivos totais. As correções anteriores de cálculos e a consulta pessoal Meu Pluggy continuam incluídas.

## Limite desta entrega

Não houve alteração no GitHub remoto nem na publicação. O repositório é público, mas a conexão disponível tinha somente leitura (push=false). A ativação do Meu Pluggy continua dependendo das autorizações e variáveis descritas em ATIVAR_MEU_PLUGGY_PESSOAL.md.
