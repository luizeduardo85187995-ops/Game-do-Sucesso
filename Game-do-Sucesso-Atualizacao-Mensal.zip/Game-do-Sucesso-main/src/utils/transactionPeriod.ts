import type { Transaction } from '../types/finance';

export function shiftMonth(month: string, offset: number): string {
  const [year, number] = month.split('-').map(Number);
  const value = new Date(Date.UTC(year, number - 1 + offset, 1));
  return `${value.getUTCFullYear()}-${String(value.getUTCMonth() + 1).padStart(2, '0')}`;
}

export function transactionsForMonth(transactions: Transaction[], month: string | null): Transaction[] {
  return transactions.filter(transaction => month === null || transaction.date.slice(0, 7) === month);
}

export function transactionTotals(transactions: Transaction[]): { income: number; expense: number; net: number } {
  let income = 0;
  let expense = 0;
  for (const transaction of transactions) {
    const cents = Math.round(transaction.amount * 100);
    if (transaction.type === 'income') income += cents;
    else expense += cents;
  }
  return { income: income / 100, expense: expense / 100, net: (income - expense) / 100 };
}
