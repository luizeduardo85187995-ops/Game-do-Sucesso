# Correção de cálculos e sincronização — 16/11/2026

## O que foi corrigido
- Um lançamento futuro novo fica pendente por padrão e não altera o saldo bancário.
- O campo Data de referência define o mês da receita/despesa, independentemente do dia em que você a cadastrou ou pagou.
- A situação Pago/Recebido movimenta a conta. Pendente não movimenta. Editar a situação ou excluir o lançamento reconcilia o saldo, sem duplicar descontos.
- Relatórios não convertem mais datas de início do mês para o mês anterior por causa do fuso horário.
- Há um filtro Próximos meses e indicação de situação em Lançamentos.
- Saldo atual e projeção de pendências são distintos. Totais mensais representam o mês de referência, incluindo lançamentos pendentes.
- Exportações incluem situação e data do pagamento.
- Falha na leitura da nuvem bloqueia a tela financeira e gravações. Dados de visitante não são importados automaticamente para outra conta.
- Carregar a conta não gera uma gravação automática nem promove um cache antigo apenas porque seu relógio é mais recente. Uma cópia anterior do cache fica preservada localmente para recuperação.

## Exemplo
Uma conta de outubro cadastrada em novembro deve ter Data de referência em outubro. Se foi paga em novembro, marque Pago e informe a data do pagamento em novembro. Ela entra nas despesas de outubro e movimenta o saldo atual uma vez.
Uma conta de dezembro ainda não paga deve ter referência em dezembro e situação Pendente. Ela não reduz o saldo bancário atual.

## IMPORTANTE: lançamentos antigos
A versão anterior descontava todos os lançamentos vinculados a uma conta imediatamente. Para não inventar pagamentos nem alterar seus saldos históricos sem confirmação, lançamentos sem situação explícita continuam tratados como já pagos/recebidos.
Revise despesas antigas que ainda não foram pagas: abra Lançamentos > Todos os meses > editar e marque Pendente. Isso devolve à conta o desconto antigo. Confira também a Data de referência.
Antes da revisão, exporte seus dados. Não ajuste o saldo manualmente e depois reverta os mesmos lançamentos, pois isso duplicaria a correção.
Dados locais que não foram enviados à nuvem precisam de recuperação/revisão explícita; esta versão não os sobrepõe automaticamente à conta remota. As chaves antigas não foram apagadas.

## Instalar e testar
Use Node.js 24. Extraia o ZIP e abra um terminal na pasta que contém package.json:

```sh
npm ci
npm test
npm run lint
npm run dev
```
Abra o endereço informado pelo terminal com `/app` no final. O arquivo index.html não deve ser aberto com duplo clique.

## Publicar na Vercel
Substitua os arquivos do repositório pelo conteúdo desta pasta, mantendo as variáveis de ambiente já configuradas na Vercel. O build usa `npm run build` e a pasta de saída é `dist`. As APIs continuam nas pastas `api/`.
Esta entrega não alterou nenhum site publicado, conta Google ou registro financeiro remoto.

## Verificações realizadas e limites
Compilação e verificação TypeScript aprovadas. Teste automatizado com React StrictMode e Firebase simulado validou isolamento de contas, falha de leitura sem gravação, ausência de gravação ao carregar, lançamento passado, pendência futura, saldo projetado, quitação, edição sem desconto duplicado e exclusão.
Login real e banco de produção não foram testados com credenciais do usuário. O usuário informou que o login voltou a funcionar. A validação visual em Chromium não pôde ser realizada por restrições deste ambiente.
